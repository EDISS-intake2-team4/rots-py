from rots import rots

def main():
    """Calculate the ROTS statistic"""
    print('ROTS-py installed successfully!')

if __name__ == "__main__":
    main()